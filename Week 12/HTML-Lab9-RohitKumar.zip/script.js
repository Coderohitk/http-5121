const sun = document.getElementById("sun");
const stage = document.getElementById("sky");
const button = document.getElementById("controlButton");

let isPaused = true;

button.addEventListener("click", () => {
    if (isPaused) {
        sun.style.animationPlayState = "running";
        stage.style.animationPlayState = "running";
        isPaused = false;
    } else {
        sun.style.animationPlayState = "paused";
        stage.style.animationPlayState = "paused";
        isPaused = true;
    }
});
